const mongoose=require("mongoose");
module.exports=mongoose.model("Group",new mongoose.Schema({
  jid:{type:String,unique:true,index:true}, name:String, active:{type:Boolean,default:false},
  moderation:{links:true,spam:true,flood:true,badWords:true},
  welcomeMessage:String, goodbyeMessage:String, createdAt:{type:Date,default:Date.now}
}));
