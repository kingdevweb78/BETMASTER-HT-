const mongoose=require("mongoose");
module.exports=mongoose.model("User",new mongoose.Schema({
  phone:{type:String,unique:true,index:true},
  name:String,
  language:{type:String,enum:["ht","fr","en"],default:"ht"},
  role:{type:String,enum:["free","vip_weekly","vip_monthly","admin"],default:"free"},
  vipExpiresAt:Date,
  favoriteTeams:[String],
  favoriteLeagues:[String],
  createdAt:{type:Date,default:Date.now}
}));
