const mongoose=require("mongoose");
module.exports=mongoose.model("Prediction",new mongoose.Schema({
  fixtureId:String, league:String, homeTeam:String, awayTeam:String,
  prediction:String, confidence:Number, correctScore:String, vip:Boolean,
  generatedAt:{type:Date,default:Date.now},
  sourceData:Object
}));
