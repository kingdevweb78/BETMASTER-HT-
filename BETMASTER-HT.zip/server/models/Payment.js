const mongoose=require("mongoose");
module.exports=mongoose.model("Payment",new mongoose.Schema({
  phone:String, plan:{type:String,enum:["weekly","monthly"]},
  amount:Number, method:{type:String,enum:["moncash","natcash"]},
  screenshotUrl:String,
  status:{type:String,enum:["pending","approved","rejected"],default:"pending"},
  reviewedBy:String, reviewedAt:Date, createdAt:{type:Date,default:Date.now}
}));
