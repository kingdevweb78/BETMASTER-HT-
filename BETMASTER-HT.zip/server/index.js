require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const mongoose = require("mongoose");
const path = require("path");

const authRoutes = require("./routes/auth");
const adminRoutes = require("./routes/admin");
const paymentRoutes = require("./routes/payments");
const predictionRoutes = require("./routes/predictions");
const groupRoutes = require("./routes/groups");
const whatsapp = require("./services/whatsapp");

const app = express();
app.use(cors());
app.use(express.json({limit:"10mb"}));
app.use(express.urlencoded({extended:true, limit:"10mb"}));
app.use(rateLimit({windowMs: 60_000, max: 120}));

app.get("/health", (_,res)=>res.json({ok:true, service:"BETMASTER HT"}));
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/predictions", predictionRoutes);
app.use("/api/groups", groupRoutes);

app.use(express.static(path.join(__dirname, "../client")));
app.get("/admin", (_,res)=>res.sendFile(path.join(__dirname,"../client/index.html")));

const port = process.env.PORT || 3000;

async function start(){
  if(process.env.MONGODB_URI){
    try { await mongoose.connect(process.env.MONGODB_URI); console.log("MongoDB connected"); }
    catch(e){ console.error("MongoDB connection failed:",e.message); }
  }
  await whatsapp.start();
  app.listen(port, ()=>console.log(`BETMASTER HT running on :${port}`));
}
start();
