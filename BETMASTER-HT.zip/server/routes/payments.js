const router=require("express").Router();
const Payment=require("../models/Payment");
router.post("/submit",async(req,res)=>{
  const {phone,plan,method,screenshotUrl}=req.body;
  const amount=plan==="weekly"?1500:4500;
  if(!phone||!["weekly","monthly"].includes(plan)||!["moncash","natcash"].includes(method))
    return res.status(400).json({error:"Invalid payment data"});
  const p=await Payment.create({phone,plan,amount,method,screenshotUrl});
  res.json({ok:true,paymentId:p._id,status:"pending"});
});
module.exports=router;
