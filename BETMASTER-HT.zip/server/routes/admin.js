const router=require("express").Router();
const auth=require("../middleware/auth");
const Payment=require("../models/Payment");
const User=require("../models/User");
router.use(auth);
router.get("/stats",async(_,res)=>{
  const [users,vip,pending,revenue]=await Promise.all([
    User.countDocuments(), User.countDocuments({role:/vip/}),
    Payment.countDocuments({status:"pending"}),
    Payment.aggregate([{ $match:{status:"approved"} },{$group:{_id:null,total:{$sum:"$amount"}}}])
  ]);
  res.json({users,vip,pending,revenue:revenue[0]?.total||0});
});
router.get("/payments",async(_,res)=>res.json(await Payment.find().sort({createdAt:-1}).limit(100)));
router.post("/payments/:id/:action",async(req,res)=>{
  if(!["approve","reject"].includes(req.params.action)) return res.status(400).json({error:"Invalid action"});
  const p=await Payment.findById(req.params.id);
  if(!p) return res.status(404).json({error:"Payment not found"});
  p.status=req.params.action==="approve"?"approved":"rejected"; p.reviewedAt=new Date(); await p.save();
  if(p.status==="approved"){
    const days=p.plan==="weekly"?7:30;
    await User.findOneAndUpdate({phone:p.phone},{
      role:p.plan==="weekly"?"vip_weekly":"vip_monthly",
      vipExpiresAt:new Date(Date.now()+days*86400000)
    },{upsert:true});
  }
  res.json({ok:true,payment:p});
});
module.exports=router;
