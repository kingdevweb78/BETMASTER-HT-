const router=require("express").Router();
const jwt=require("jsonwebtoken");
router.post("/login",async(req,res)=>{
  const {email,password}=req.body;
  if(email!==process.env.ADMIN_EMAIL || password!==process.env.ADMIN_PASSWORD)
    return res.status(401).json({error:"Invalid credentials"});
  const token=jwt.sign({email,role:"admin"},process.env.JWT_SECRET,{expiresIn:"12h"});
  res.json({token});
});
module.exports=router;
