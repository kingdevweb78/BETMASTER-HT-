const router=require("express").Router();
const Group=require("../models/Group");
router.get("/",async(_,res)=>res.json(await Group.find().sort({createdAt:-1})));
router.post("/toggle",async(req,res)=>{
  const {jid,active}=req.body;
  const g=await Group.findOneAndUpdate({jid},{active:!!active},{upsert:true,new:true});
  res.json(g);
});
module.exports=router;
