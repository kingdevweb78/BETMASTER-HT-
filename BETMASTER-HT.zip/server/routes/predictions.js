const router=require("express").Router();
const {analyzeMatch}=require("../services/prediction");
router.post("/analyze",(req,res)=>{
  const {homeTeam,awayTeam,data={}}=req.body;
  if(!homeTeam||!awayTeam) return res.status(400).json({error:"Teams required"});
  res.json({...analyzeMatch(homeTeam,awayTeam,data), disclaimer:"Prediction is an estimate based on available data and is not guaranteed."});
});
module.exports=router;
