function clamp(n,min,max){return Math.max(min,Math.min(max,n));}
function analyzeMatch(home,away,d){
  const hf=Number(d.homeForm||0.5), af=Number(d.awayForm||0.5);
  const hg=Number(d.homeGoals||1.2), ag=Number(d.awayGoals||1.0);
  const h2h=Number(d.h2hHome||0.5);
  const homeScore=clamp(hf*.35+(hg/3)*.25+h2h*.20+.20,0,1);
  const awayScore=clamp(af*.35+(ag/3)*.25+(1-h2h)*.20+.20,0,1);
  const total=homeScore+awayScore;
  const winner=homeScore>awayScore?"1":awayScore>homeScore?"2":"X";
  const confidence=clamp(Math.round((Math.abs(homeScore-awayScore)*100)+50),50,95);
  const over25=(hg+ag)>=2.5;
  const btts=hg>=1&&ag>=1;
  const correctScore=winner==="1"?"2-1":winner==="2"?"1-2":"1-1";
  return {home,away,matchWinner:winner,doubleChance:winner==="X"?"1X":winner==="1"?"1X":"X2",
    over15:(hg+ag)>=1.5,over25,over35:(hg+ag)>=3.5,btts,correctScore,
    confidence,totalIndex:Number(total.toFixed(2))};
}
module.exports={analyzeMatch};
