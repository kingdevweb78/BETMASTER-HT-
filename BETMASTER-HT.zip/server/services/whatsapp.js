const makeWASocket=require("@whiskeysockets/baileys").default;
const {useMultiFileAuthState,DisconnectReason}=require("@whiskeysockets/baileys");
const P=require("pino");
let sock=null;
async function start(){
  const {state,saveCreds}=await useMultiFileAuthState("auth_info_betmaster");
  sock=makeWASocket({auth:state,logger:P({level:"silent"})});
  sock.ev.on("creds.update",saveCreds);
  sock.ev.on("connection.update",({connection,lastDisconnect,qr})=>{
    if(qr) console.log("WhatsApp pairing/QR state available. Use a current Baileys pairing flow for the configured phone.");
    if(connection==="open") console.log("BETMASTER HT WhatsApp connected");
    if(connection==="close" && lastDisconnect?.error?.output?.statusCode!==DisconnectReason.loggedOut) start();
  });
  sock.ev.on("messages.upsert",async({messages})=>{
    const m=messages[0]; if(!m?.message||m.key.fromMe)return;
    const text=m.message.conversation||m.message.extendedTextMessage?.text||"";
    if(text.trim()===".menu") await sock.sendMessage(m.key.remoteJid,{text:"🏆 BETMASTER HT\n\n.predict\n.matches\n.results\n.stats\n.table\n.vip\n.subscribe\n.status\n.help\n.language"});
    if(text.trim()===".vip") await sock.sendMessage(m.key.remoteJid,{text:"👑 VIP BETMASTER HT\nWeekly: 1500 HTG\nMonthly: 4500 HTG\n\nUse .subscribe"});
    if(text.trim()===".subscribe") await sock.sendMessage(m.key.remoteJid,{text:"💳 Abònman VIP\nWeekly: 1500 HTG\nMonthly: 4500 HTG\n\nMonCash: +50944*******\nNatCash: +5095********\n\nVoye kaptur peman an pou validation admin."});
  });
}
async function sendText(jid,text){if(sock) return sock.sendMessage(jid,{text});}
module.exports={start,sendText};
