# BETMASTER HT

Premium WhatsApp football prediction bot with admin dashboard.

## Features
- WhatsApp Web pairing-code connection
- Admin JWT authentication
- VIP weekly/monthly subscription workflow
- Payment screenshot upload endpoint
- Group activation/deactivation
- Football data API integration point
- Prediction service with confidence estimates
- Kreyòl / Français / English message catalog
- MongoDB models
- Docker deployment

## Run
1. Copy `.env.example` to `.env`.
2. Set MongoDB and secrets.
3. Run `npm install`.
4. Run `npm start`.
5. Open `/admin` for the dashboard.
6. Send the configured phone number to the pairing-code endpoint.

## Important
Use WhatsApp automation only in ways permitted by WhatsApp and applicable terms. Pairing code is not the same as the official WhatsApp Business Platform API.

Predictions are estimates, not guaranteed outcomes. The prediction service should only publish statistics that are actually available from the configured football-data provider.
